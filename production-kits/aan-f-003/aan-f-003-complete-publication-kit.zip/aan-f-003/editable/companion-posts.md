# The Sensory Textile Room — companion posts

## Carousel A — Your skin does not read the fiber label

Your skin does not read the fiber label.

It encounters pressure, vibration, stretch, temperature, friction and chemical signals—through a garment built from far more than its listed fiber.

Fiber becomes yarn. Yarn becomes weave or knit. Construction adds seams, labels, closures, tension and layers. Then heat, moisture, movement, duration, body site and expectation change the encounter again. A 2024 laboratory study found that measured tactile sensitivity affected how participants rated textile samples. But participants touched samples by hand; they did not wear a seam at the neck for eight hours. The result supports individual difference, not a promise that silk will soothe or wool will irritate everyone. “Natural,” “soft” and “sensory-friendly” are not standardized comfort guarantees.

Ask a Neuroscientist turns the vague claim “my nervous system hates this fabric” into variables a wearer or designer can actually observe.

Comfort is not stored in a fiber. It emerges in the encounter among textile, garment, body and day.

Save the carousel before your next fitting and send it to a designer who wants a more useful sensory-inclusion brief.

---

## Carousel B — This garment. This body. This day.

“I cannot wear wool” may be true—and still be too broad to tell you what to change.

A usable sensory record starts with the exact garment and the exact contact, not a material category alone.

Name the piece. Locate the contact: neck, waist, forearm, foot or whole body. Observe surface, pressure, heat, moisture, movement and repetition. Add the situation: quiet or crowded, resting or exercising, five minutes or a full workday. Then choose descriptive words—settling, neutral, distracting, itchy, painful, entrapping—instead of turning one encounter into a verdict about every garment or every nervous system. Test one safe change at a time. Never force exposure to pain, allergy or harm.

This is Ask a Neuroscientist as a field practice: specific observation without diagnosis by infographic.

The point is not to talk yourself out of discomfort. It is to describe it precisely enough to design around it.

Open the private Sensory Textile Field Map, record one garment, and save this carousel for the next comparison.
