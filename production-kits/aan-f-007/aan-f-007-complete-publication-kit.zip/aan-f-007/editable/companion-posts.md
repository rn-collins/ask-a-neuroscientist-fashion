# The Role Room — companion posts

## Carousel A — A uniform is read before its wearer speaks

A uniform is read before its wearer speaks.

Color, cut, insignia, equipment and repetition make a role visible. The observer’s next move is often inference.

We may infer status, competence, safety, threat or belonging from a uniform. But visible cues are not verified credentials, conduct, policy or relationship. Personal encounters, media, community memory and culture also shape what the uniform means before any present interaction occurs. That gap matters because a signal can organize attention without revealing a person’s character or intentions. Institutions give uniforms authority, assign who may wear them and enforce the consequences of getting the signal wrong.

Ask a Neuroscientist separates what entered the eyes from what the mind supplied—and what the record can actually verify.

The uniform may be immediately legible. The person inside it is not.

Save the visible/inferred/known/history framework and use the private Uniform Encounter Map before turning one signal into a verdict.

---

## Carousel B — Do uniforms change behavior?

Do uniforms change behavior? The honest answer needs a fitting.

Different studies test different garments, people, tasks and institutions. They cannot be stacked into one universal “uniform effect.”

A broad review supports dress as part of person perception, not mind-reading. One experiment found a status-attention bias among students wearing police-style clothing; it did not study police conduct. Another shifted a moral-choice task using military and Red Cross clothing; it did not measure real service. An fMRI task using uniform self-images engaged distributed networks, not a “uniform center.” A hospital case study showed how a uniform change rearranged professional boundaries in one institution, not every workplace. The evidence supports role salience and social signaling under specific conditions.

Ask a Neuroscientist refuses to turn an interesting collection of narrow studies into a fixed psychology sewn into cloth.

Uniforms can organize perception and institutions. They do not contain obedience, competence, aggression or belonging.

Keep the final claim with the study-by-study carousel, and share it with anyone designing a uniform policy rather than merely styling one.
