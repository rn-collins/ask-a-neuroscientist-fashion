# Clothes and Cognition — companion posts

## Carousel A — Can clothes change cognition?

Can clothes change cognition? Yes is the tempting answer. The evidence asks for a much smaller sentence.

The phrase “enclothed cognition” came from a 2012 lab-coat experiment. Participants wearing a coat described as a doctor’s coat made fewer errors on one attention task than comparison groups.

That result became a much bigger cultural promise: dress for the person you want to become and your brain will follow. But the experiment measured a narrow task, not intelligence, creativity, confidence or permanent “rewiring.” Its own theory depended on both wearing the garment and the meaning attached to it. Then a preregistered direct replication did not recover the key effect. Clothing still changes pressure, posture, movement, temperature and the way other people respond to us. What it does not give us is a universal cognitive upgrade.

This is exactly why Ask a Neuroscientist exists: to keep a genuinely interesting question while making the mechanism fit the measure.

The useful question is not “Do clothes change the brain?” It is “What changed here: the body, the task, the meaning, the room—or some combination?”

Save the carousel for the next time “dress for success” is presented as neuroscience, then open the next carousel for the replication people usually leave out.

---

## Carousel B — The replication people omit

The most famous study about clothes changing cognition came with a sequel most people never mention.

In 2019, Devin Burns, Elizabeth Fox, Michael Greenstein, Gayla Olbricht and DeMaris Montgomery preregistered a direct replication of the lab-coat experiment.

They repeated the critical design and did not recover the original Stroop effect. That null result does not prove clothing never matters. It tells us something more disciplined: the viral sentence is stronger than the repeatable evidence. A garment can alter sensory input, restrict or enable movement, cue a role and change how other people read its wearer. Those are several pathways, not one magic switch. “Disputed” or “qualified” is therefore more accurate than either “proven” or “debunked.”

Ask a Neuroscientist is not here to flatten a complicated finding into a gotcha. It is here to show where the claim ends and the better questions begin.

Replication did not make clothing uninteresting. It made the story more honest.

Share this with someone who has heard the lab-coat claim, and keep the source slide with the post so the missing half of the story travels too.
